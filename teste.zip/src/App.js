import React from 'react';
import './App.scss';
import Home from './home';

const App = () => {
  return (
   <Home/>
  );
}

export default App;
