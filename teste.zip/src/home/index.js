import React from 'react'
import Navbar from '../components/navbar';
import Header from '../components/header';
import Main from '../components/main';
import News from '../components/news';
import Footer from '../components/footer';
import Social from '../components/social';

const Home = () => {
    return (
        <div>
            <Navbar/>
            <Header/>
            <Main/>
            <News/>
            <Social/>
            <Footer/>
        </div>
    )
}

export default Home