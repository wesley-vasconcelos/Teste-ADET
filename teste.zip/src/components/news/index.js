import React from "react";
import "./style.scss";

const Item = ({ src }) => (
  <div className='item'>
    <div className='image'>
      <img src={src} />
    </div>
    <div className='group'>
      <p className='title'>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet ducimus minima, nesciunt{" "}
      </p>
      <div className='desc'>
        <p className='price line'>R$ 1040,00 </p>
        <p className='price'>R$ 900,00 </p>
      </div>
      <p>2x de R$ 450,00 sem juros</p>
      <button className='button'>Comprar</button>
    </div>
  </div>
);

const News = () => {
  return (
    <div className='news'>
      <h2 className='uppercase title'>Lançamentos</h2>
      <div className='slider'>
        <Item src={require("../../assets/imagens/anel2.png")} />
        <Item src={require("../../assets/imagens/anel3.png")} />
        <Item src={require("../../assets/imagens/anel4.png")} />
        <Item src={require("../../assets/imagens/anel2.png")} />
        <Item src={require("../../assets/imagens/anel3.png")} />
        <Item src={require("../../assets/imagens/anel4.png")} />
      </div>
      <div className='group-images'>
        <div>
          <img src={require("../../assets/imagens/claritas.png")} />
        </div>
        <div className="column">
          <div>
            <img src={require("../../assets/imagens/ades.png")} />
          </div>
          <div>
            <img src={require("../../assets/imagens/otera.png")} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default News;
