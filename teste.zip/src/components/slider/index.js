import React, { useEffect, useState } from 'react'

const Slider = ({array, image, children, steps}) => {
    const [slider, setSlider] = useState(1)
    let valueBack = (slider - 1)
    let valueNext = (slider + 1)
    useEffect(() => {
        setInterval(() => {
            let value = (slider + 1)
            slider != array.length ? setSlider(value) : setSlider(1)
        }, 3000)
    }, [slider])

    return (
        <div className="content">
            {
                array.map(item => slider === item.step && image ? <img className="image" src={item.url} /> : children)
            }
            <div className="actions">
                <div></div>
                <div className="arrows">
                    <img onClick={() => slider >= 2 ? setSlider(valueBack) : setSlider(array.length)} className="arrow-right" src={require('../../assets/icons/arrow.svg')} />
                    <img onClick={() => slider < array.length ? setSlider(valueNext) : setSlider(1)} src={require('../../assets/icons/arrow.svg')} />
                </div>
                <div className="steps" >
                    {
                        steps && array.map(item => <div className={`circle ${slider === item.step && 'active'}`}></div>)
                    }
                </div>
            </div>
        </div>
    )
}

export default Slider