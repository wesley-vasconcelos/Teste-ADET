import React, { useEffect, useState } from "react";

const Slider = ({ array, image, children, steps, maxSteps }) => {
  const [slider, setSlider] = useState(1);
  const [stop, setStop] = useState(false);

  let valueBack = slider - 1;
  let valueNext = slider + 1;

  const timer = () => {
    setInterval(() => {
      let value = slider + 1;
      !stop && slider != (maxSteps || array.length) ? setSlider(value) : setSlider(1);
    }, 3000);
  }

  useEffect(() => {
      timer()
  }, [])

  const back = () => {
    slider >= 2 ? setSlider(valueBack) : setSlider(maxSteps || array.length);
    return setStop(true);
  };

  const next = () => {
    slider < (maxSteps || array.length) ? setSlider(valueNext) : setSlider(1);
    return setStop(true);
  };
  return (
    <div className='content'>
      {image
        ? array.map(item => slider === item.step && <img className='image' src={item.url} />)
        : children}
      <div className='actions'>
        <div></div>
        <div className='arrows'>
          <img
            onClick={back}
            className='arrow-right'
            src={require("../../assets/icons/arrow.svg")}
          />
          <img onClick={next} src={require("../../assets/icons/arrow.svg")} />
        </div>
        <div className='steps'>
          {steps &&
            array.map(item => <div className={`circle ${slider === item.step && "active"}`}></div>)}
        </div>
      </div>
    </div>
  );
};

export default Slider;
