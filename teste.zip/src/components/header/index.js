import React, { useState, useEffect } from 'react'
import './style.scss'
import image1 from '../../assets/imagens/banner-principal1.png'
import image2 from '../../assets/imagens/banner-principal1.png'
import image3 from '../../assets/imagens/banner-principal1.png'
import Slider from '../slider';

const images = [
    {
        url: image1,
        step: 1
    },
    {
        url: image2,
        step: 2
    },
    {
        url: image3,
        step: 3
    }
]

const Header = () => {
    return (
        <div className="header">
            <div className="header-slider">
                <Slider image steps array={images} />
            </div>
            <div className="vantagens">
                <div className="item">
                    <img src={require('../../assets/icons/entrega.svg')} />
                    <p className="uppercase">Frete Grátis acima de <span className="bold">R$200,00</span> </p>
                </div>
                <div className="item">
                    <img src={require('../../assets/icons/sem-juros.svg')} />
                    <p className="uppercase"> Até <span className="bold">10X</span> sem juros </p>
                </div>
                <div className="item">
                    <img src={require('../../assets/icons/desconto.svg')} />
                    <p className="uppercase"><span className="bold">10% Off</span> à vista no cartão ou boleto </p>
                </div>
                <div className="item">
                    <img src={require('../../assets/icons/cadeado.svg')} />
                    <p className="uppercase"><span className="bold">Segurança</span> em todas etapas da compra </p>
                </div>
            </div>
        </div>
    )
}

export default Header