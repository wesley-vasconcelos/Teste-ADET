import React from 'react'
import './style.scss'

const Navbar = () => {
    return (
        <div className="navbar">
            <div className="menu">
                <div className="wrapper">
                    <p className="uppercase">Meus Pedidos</p>
                    <p className="uppercase">Entrar / Cadastre-se</p>
                </div>
            </div>
            <div className="header">
                <div className="main">
                    <div className="box-search">
                        <input className="search" placeholder="Digite o que você procura" />
                        <img src={require('../../assets/icons/BUSCA.svg')} />                        
                    </div>
                    <div className="logo">
                        <img src={require('../../assets/imagens/logo.png')} />
                    </div>
                    <div className="pedidos">
                        <div className="item">
                         <img src={require('../../assets/icons/favorito.svg')} />
                            <p className="uppercase">Lista de desejos</p>
                        </div>
                        <div className="item">
                            <img src={require('../../assets/icons/loja.svg')} />
                            <p className="uppercase">02 itens</p>
                        </div>
                    </div>
                </div>
                <div className="navigation">
                    <a href="#" className="text-navigation uppercase">Novidades</a>
                    <a href="#" className="text-navigation uppercase">Anéis</a>
                    <a href="#" className="text-navigation uppercase">Brincos</a>
                    <a href="#" className="text-navigation uppercase">Colares</a>
                    <a href="#" className="text-navigation uppercase">Conjuntos</a>
                    <a href="#" className="text-navigation uppercase sales">Sales</a>
                </div>
            </div>
        </div>
    )
}

export default Navbar