import React from "react";
import "./style.scss";
import image1 from "../../assets/imagens/slide2-1.png";
import image2 from "../../assets/imagens/slide2-2.png";
import image3 from "../../assets/imagens/slide2-3.png";
import image4 from "../../assets/imagens/slide2-4.png";
import image5 from "../../assets/imagens/slide2-5.png";
import image6 from "../../assets/imagens/slide2-6.png";
import Slider from "../slider";

const images = [
  {
    url: image1,
    step: 1
  },
  {
    url: image2,
    step: 2
  },
  {
    url: image3,
    step: 3
  },
  {
    url: image4,
    step: 4
  },
  {
    url: image5,
    step: 5
  },
  {
    url: image6,
    step: 6
  },
  {
    url: image1,
    step: 1
  },
  {
    url: image2,
    step: 2
  },
  {
    url: image3,
    step: 3
  },
  {
    url: image4,
    step: 4
  },
  {
    url: image5,
    step: 5
  },
  {
    url: image6,
    step: 6
  }
];

const Social = () => {
  return (
    <div className='social'>
      <div className='insta'>
        <div className='box-title'>
          <div>
            <img src={require("../../assets/icons/INSTAGRAM.svg")} />
          </div>
          <p className='uppercase title'>@NayaraMarra</p>
        </div>
      </div>

      <div className='slider'>
        {
          images.map(item => <img className="image" src={item.url}/> )
        }
      </div>

      <div className='email'>
        <div className='group'>
          <div>
            <img src={require("../../assets/icons/email.svg")} />
          </div>
          <p className='uppercase'>Cadastre-se e receba ofertas exclusivas</p>
        </div>
        <div className='box-input'>
          <input placeholder='E-mail' />
          <div className='send'>
            <img src={require("../../assets/icons/arrow.svg")} />
          </div>
        </div>
        <div className='redes-sociais'>
          <img src={require("../../assets/icons/redes-sociais.svg")} />
        </div>
      </div>
    </div>
  );
};

export default Social;
