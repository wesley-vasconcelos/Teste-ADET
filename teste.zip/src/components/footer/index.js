import React from 'react'
import './style.scss'

const Footer = () => {
    return (
        <div className="footer">
            <div className="group">
                <p className="title uppercase bold"> Central de Ajuda </p>
                <a href="#"> Central de Atendimento </a>
                <a href="#"> Envio e Entrega </a>
                <a href="#"> Navegando e Comprando </a>
                <a href="#"> Trocas e Devoluções </a>
                <a href="#"> Fale Conosco </a>
                <a href="#"> Mapa do Site </a>
            </div>
            <div className="group">
                <p className="title uppercase bold"> Institucional </p>
                <a href="#"> Quem Somos </a>
                <a href="#"> Nossas Lojas </a>
                <a href="#"> Politica de Privacidade </a>
                <a href="#"> Afiliados </a>
            </div>
            <div className="group">
                <p className="title uppercase bold"> Atendimento </p>
                <div className="atendimento">
                    <div>
                        <img src={require('../../assets/icons/call.svg')} />
                    </div>
                    <div className="column">
                        <p className="bold">Televendas 0800 - 0000 | SAC 0800 - 0000 </p>
                        <p className="text">Horario de Atendimento </p>
                        <p className="text">De segunda a sexta das 00 ás 00 </p>
                    </div>

                </div>
            </div>
            <div className="group">
                <p className="title uppercase"> Certificados </p>
                <div>
                    <img src={require('../../assets/icons/certificado.svg')} />
                </div>
            </div>
        </div>
    )
}

export default Footer