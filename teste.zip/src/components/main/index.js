import React from "react";
import "./style.scss";

const Item = ({ src, title }) => (
  <div className='item'>
    <div className='image'>
      <img src={src} />
    </div>
    <div className='desc'>
      <h4 className='uppercase'> {title} </h4>
      <button className='button uppercase'>Shop now</button> 
    </div>
  </div>
);

const Main = () => {
  return (
    <div className='main'>
      <div className='image-horizontal'>
        <div className='left'>
          <img src={require("../../assets/imagens/left.png")} />  
        </div>
        <div className='right'>
          <img src={require("../../assets/imagens/right.png")} />
        </div>
      </div>
      <div className='center'>
        <div className='image'>
          <img src={require("../../assets/imagens/deitada.png")} />
        </div>
        <div className='group'>
          <Item src={require("../../assets/imagens/anel.png")} title='Anéis' />
          <Item src={require("../../assets/imagens/colar-duplo.png")} title='Brincos' />
          <Item src={require("../../assets/imagens/colar.png")} title='Colares' />
        </div>
      </div>
    </div>
  );
};

export default Main;
